<?php

namespace App\Controller;

use App\Entity\Timer;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Serializer;

class TimerController extends AbstractController
{

    /**
    * @var EntityManagerInterface
    */
    private $entityManager;

    /**
    * @var \Doctrine\Common\Persistence\ObjectRepository
    */
    private $timerRepository;

    public function __construct(EntityManagerInterface $entityManager)
   {
       $this->entityManager = $entityManager;
       $this->timerRepository = $entityManager->getRepository('App:Timer');
   }

   /**
    * @Route("/timer", name="timer", methods={"GET"})
    * @param Request $request
    * @return array|JsonResponse|null|object
    */

   public function createTimer(Request $request)
   {
       $content = $request->query;
       //print_r($content->get('uname'));
       $timer = new Timer();
       $timer->setName($content->get('uname'));
       $timer->setStartedAt($content->get('startedAt'));
       $timer->setStoppedAt($content->get('stoppedAt'));
       $this->updateDatabase($timer);

       // Serialize object into Json format
       $jsonContent = $this->serializeObject($timer);
       return new Response($jsonContent, Response::HTTP_OK);
   }

   public function serializeObject($object)
   {
       $encoders = new JsonEncoder();
       $normalizers = new ObjectNormalizer();
       $normalizers->setCircularReferenceHandler(function ($obj) {
          return $obj->getId();
       });
       $serializer = new Serializer(array($normalizers), array($encoders));
       $jsonContent = $serializer->serialize($object, 'json');
       return $jsonContent;
   }
 
   public function updateDatabase($object)
   {
       $this->entityManager->persist($object);
       $this->entityManager->flush();
   }
}
