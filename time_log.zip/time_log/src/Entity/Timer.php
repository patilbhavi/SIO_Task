<?php

namespace App\Entity;

use App\Repository\TimerRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=TimerRepository::class)
 */
class Timer
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string")
     */
    private $name;

   /**
    * @ORM\Column(type="datetime", name="started_at")
    */
    private $startedAt;

    /**
     * @ORM\Column(type="datetime", name="stopped_at")
     */
    private $stoppedAt; 

    public function getId(): ?int
    {
        return $this->id;
    }

    public function setId($id): ?int
    {
       $this->id = $id;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName($name)
    {
        $this->name = $name;
    }

    public function getStartedAt(): ?string
    {
        return $this->startedAt;
    }

    public function setStartedAt($startedAt)
    {
        $this->startedAt = $startedAt;
    }

    public function getStoppedAtt(): ?string
    {
        return $this->stoppedAt;
    }

    public function setStoppedAt($stoppedAt)
    {
        $this->stoppedAt = $stoppedAt;
    }

}
